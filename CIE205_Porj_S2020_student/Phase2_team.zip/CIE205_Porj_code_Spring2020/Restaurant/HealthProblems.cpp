#include "HealthProblems.h"
#include "../Restaurant/Rest/Restaurant.h"
#include"../Restaurant/Rest/Order.h"

HealthProblems::HealthProblems(int eTime, int oID):Event(eTime, oID)
{

}

void HealthProblems::Execute(Restaurant* pRest)
{

}
